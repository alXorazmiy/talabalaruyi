from django.contrib import admin

from .models import *


admin.site.register(Floor)
admin.site.register(Room)
admin.site.register(Faculty)
admin.site.register(Student)
admin.site.register(Payments)
admin.site.register(Image)
